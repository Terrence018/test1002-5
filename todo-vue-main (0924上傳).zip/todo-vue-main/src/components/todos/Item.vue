<script setup>
const props = defineProps(['todo', 'todos'])
const emits = defineEmits(['toggle_todo', 'remove_todo'])

function toggleComplete(e) {
  const { id } = e.currentTarget.dataset

  const todo = props.todos.find((t) => t.id == id)

  if (todo) {
    todo.completed = !todo.completed
    emits('toggle_todo')
  }
}

function completedClass(todo) {
  if (todo.completed) {
    return 'line-through'
  }

  return ''
}

function handleRemoveTodo(e) {
  const { id } = e.currentTarget.dataset

  emits('remove_todo', id)
}
</script>

<template>
  <li>
    <div>
      <input :checked="todo.completed" @click="toggleComplete" :data-id="todo.id" type="checkbox" class="checkbox">
      <span :class="completedClass(todo)">
        {{ todo.task }}
      </span>
    </div>

    <span class="text-sm">
      {{ todo.createdAt }}
      <button @click="handleRemoveTodo"
              :data-id="todo.id"
              class="btn btn-xs btn-error">X</button>
    </span>
  </li>
</template>
