<script setup>
import { ref } from "vue"
import dayjs from "dayjs"

const emits = defineEmits(['add_todo'])

const todo = ref("")

function addTodo() {
  const todoValue = todo.value

  if (todoValue != '') {

    const todoObj = {
      id: crypto.randomUUID(),
      task: todoValue,
      createdAt: dayjs().format('YYYY/MM/DD hh:mm'),
      completed: false
    }

    emits('add_todo', todoObj)

    todo.value = ''
  }
}
</script>

<template>
  <section class="flex">
    <input @keyup.enter="addTodo" v-model.trim="todo" type="text" class="input text-4xl w-full">
    <button @click="addTodo" class="btn mx-2 btn-success">+</button>
  </section>
</template>
