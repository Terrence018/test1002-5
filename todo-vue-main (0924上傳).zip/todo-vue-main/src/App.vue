<script setup>
import { ref, onMounted } from 'vue';
import TodoItem from "./components/todos/Item.vue"
import AddTask from './components/todos/AddTask.vue';

const todos = ref([])

function handleAddTodo(todo) {
  console.log(todo);

  todos.value.unshift(todo)
  saveTodo()
}

function removeTodo(id) {
  if (id) {
    const idx = todos.value.findIndex((t) => t.id == id)
    if (idx >= 0) {
      todos.value.splice(idx, 1)
    }

    saveTodo()
  }
}

function saveTodo() {
  const todoJSON = {
    todos: todos.value
  }

  localStorage.setItem("tfdsfsdfsdodo-fsddapp", JSON.stringify(todoJSON))
}

onMounted(() => {
  const data = JSON.parse(localStorage.getItem('tfdsfsdfsdodo-fsddapp'))

  if(data) {
    todos.value = data.todos
  }
})
</script>

<template>
  <main class="container mx-auto px-6 py-2">
    <AddTask @add_todo="handleAddTodo" />

    <section>
      <ul>
        <TodoItem class="flex justify-between"
                  :todo="todo"
                  :todos="todos"
                  :key="todo.id"
                  @toggle_todo="saveTodo"
                  @remove_todo="removeTodo"
                  v-for="todo in todos" />
      </ul>
    </section>
  </main>
</template>
